
#include <stdint.h>

#include "../stream_salsa20.h"
#include "crypto_stream_salsa20.h"

extern struct crypto_stream_salsa20_implementation
    crypto_stream_salsa20_ref_implementation;
