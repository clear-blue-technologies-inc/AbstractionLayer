#ifndef aegis128l_aesni_H
#define aegis128l_aesni_H

#include "implementations.h"

extern struct aegis128l_implementation aegis128l_aesni_implementation;

#endif